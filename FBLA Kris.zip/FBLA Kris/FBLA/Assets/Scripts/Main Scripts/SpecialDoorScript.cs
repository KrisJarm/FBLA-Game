﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpecialDoorScript : MonoBehaviour
{

    public GameObject icon;

    private void OnTriggerStay2D(Collider2D collision)
    {
        icon.SetActive(collision.gameObject.tag == "Player");

    }

    public void OnTriggerExit2D(Collider2D collision)
    {

        icon.SetActive(false);

    }

}
