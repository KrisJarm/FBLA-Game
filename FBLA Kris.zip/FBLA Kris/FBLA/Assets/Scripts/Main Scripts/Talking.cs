﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Talking : MonoBehaviour
{
    public GameObject TextObject; // Common text object in scene
    public Transform TextPosition;

    private bool talking;

    public void Start()
    {
        talking = false;
    }

    public void FixedUpdate()
    {
        if(talking)
        {
            TextObject.transform.position = Camera.main.WorldToScreenPoint(TextPosition.position);
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.CompareTag("Player"))
        {
            TextObject.GetComponent<Text>().text = this.GetComponent<Text>().text;
            talking = true;
            TextObject.transform.position = Camera.main.WorldToScreenPoint(TextPosition.position);
            TextObject.SetActive(true);
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            TextObject.SetActive(false);
            talking = false;
        }
    }
}
