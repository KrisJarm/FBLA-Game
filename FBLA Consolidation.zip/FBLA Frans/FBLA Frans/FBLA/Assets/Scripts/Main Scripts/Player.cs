﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    public GameObject dart;
    public GameObject icon;
    public float speed = 10;
    public Rigidbody2D rb;
    public bool canJump;
    public float jumpHeight;

    public bool isGrounded;

    int questionNumber = 1;


    // Update is called once per frame
    void Update()
    {
        //int h = 0;

        // MOVEMENT
        if (Input.GetButton("Horizontal"))
        {
            if (Input.GetAxis("Horizontal") > 0) { rb.velocity = new Vector2(speed, rb.velocity.y);}
            else if (Input.GetAxis("Horizontal") < 0) { rb.velocity = new Vector2(-speed, rb.velocity.y);}
        }
        else {
            rb.velocity = new Vector2(0, rb.velocity.y);
        }

        /*Vector3 tempVect = new Vector3(h, 0, 0);
        tempVect = tempVect * speed * Time.deltaTime; // Distance = speed * amount of time has passed, (normalized only cares for direction)
        transform.position = transform.position + tempVect;
        rb.MovePosition(rb.transform.position + tempVect); // Messes with the forces from jumping*/

        // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        Debug.Log(questionNumber);

        // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        // JUMPING
        if (canJump && isGrounded && Input.GetButtonDown("Jump"))
        {
            rb.AddForce(new Vector2(0,jumpHeight));
        }

        //Interaction Icon Code
        icon.transform.position = new Vector3(gameObject.transform.position.x, gameObject.transform.position.y + 3, gameObject.transform.position.z);

    }

    public void OnTriggerStay2D(Collider2D collision)
    {
        if (!isGrounded) { isGrounded = collision.gameObject.tag == "Floor"; }
    }

    public void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Floor") { isGrounded = false; }
    }

    public int getQuestion() {

        return questionNumber;

    }

}