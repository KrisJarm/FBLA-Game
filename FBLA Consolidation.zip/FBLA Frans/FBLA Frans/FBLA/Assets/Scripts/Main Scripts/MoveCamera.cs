﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveCamera : MonoBehaviour
{
    public int minCamera;
    public int maxCamera;
    public float verticalOffset; //adds number to position of camera's y-value
    public Transform playerTrans;
    public Transform leftBound;
    public Transform rightBound;

    private float leftBoundX;
    private float rightBoundX;

    // Start is called before the first frame update
    void Start()
    {
        /*leftBoundX = leftBound.position.x;
        rightBoundX = rightBound.position.x;
        GameObject.Destroy(leftBound.gameObject); // Destroys LeftBound after storing its value
        GameObject.Destroy(rightBound.gameObject); // Destroys RightBound after storing its value */

        this.transform.DetachChildren();
        playerTrans = GameObject.FindGameObjectWithTag("Player").GetComponent<Transform>(); // Automatically sets playerTrans variable
    }

    // Update is called once per frame
    void Update()
    {
        /*float x = playerTrans.transform.position.x > leftBoundX && playerTrans.transform.position.x < rightBoundX ?
            playerTrans.position.x : this.transform.position.x;*/
        float x = playerTrans.transform.position.x > leftBound.position.x && playerTrans.transform.position.x < rightBound.position.x ?
            playerTrans.position.x : this.transform.position.x;
        this.transform.position = new Vector3(x, playerTrans.position.y + verticalOffset, -100);
    }
}
