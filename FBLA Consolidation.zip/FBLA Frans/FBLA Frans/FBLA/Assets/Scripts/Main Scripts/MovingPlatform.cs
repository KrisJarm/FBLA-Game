﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovingPlatform : MonoBehaviour
{
    public Rigidbody2D rb;
    public Transform endPoint;
    public float speed;
    public float delay;
    public float delayCount;

    private Vector2 startVector;
    private Vector2 endVector;
    private bool movingToEnd;
    private bool delayed;

    // Start is called before the first frame update
    void Start()
    {
        delayCount = delay;
        movingToEnd = true;
        delayed = false;
        startVector = this.transform.position;
        endVector = endPoint.position;
        GameObject.Destroy(endPoint.gameObject);
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if(!delayed)
        {
            Vector2 other = movingToEnd ? endVector : startVector;
            
            Vector2 nextPos = Vector2.MoveTowards(rb.position, other, speed * Time.deltaTime);
            if(nextPos.Equals(rb.position))
            {
                delayed = true;
                movingToEnd = !movingToEnd;
            }
            else
            {
                rb.MovePosition(nextPos);
            }
        }
        else
        {
            delayCount -= Time.deltaTime;
            if(delayCount <= 0)
            {
                delayed = false;
                delayCount = delay;
            }
        }
    }
}
