﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InteractionIconControl : MonoBehaviour
{

    void Start()
    {
        gameObject.SetActive(false);     
        
    }    

}
