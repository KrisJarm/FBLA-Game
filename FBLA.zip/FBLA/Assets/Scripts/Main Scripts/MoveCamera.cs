﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveCamera : MonoBehaviour
{
    public int minCamera;
    public int maxCamera;
    public int verticalOffset; //adds number to position of camera's y-value
    public Transform playerTrans;
    public Transform leftBound;
    public Transform rightBound;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        float x = this.transform.position.x;
        if (playerTrans.transform.position.x > leftBound.position.x && playerTrans.transform.position.x < rightBound.position.x)
        {
            x = playerTrans.position.x;
        }
        this.transform.position = new Vector3(x, playerTrans.position.y + verticalOffset, -100);
    }
}
