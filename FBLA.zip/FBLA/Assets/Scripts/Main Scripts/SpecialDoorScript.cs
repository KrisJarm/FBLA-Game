﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpecialDoorScript : MonoBehaviour
{

    public GameObject icon;
    public GameObject player;
    public GameObject leftBound;
    public GameObject rightBound;

    public bool correct = false;

    public int doorNumber;
    int questionNumber;

    public void Update()
    {
        //gets The question number and tells the door if it is the correct door for the question
        questionNumber = player.GetComponent<Player>().getQuestion();

        if (questionNumber == 1) {
            if (doorNumber == 3) {

            }
        }
    }

    private void OnTriggerStay2D(Collider2D collision)
    {

        icon.SetActive(collision.gameObject.tag == "Player");

        if (collision.gameObject.tag == "Player" && (Input.GetKeyDown(KeyCode.UpArrow) || Input.GetKeyDown(KeyCode.W))) {
            //decimals are just how the numbers ended up lol. If you want to make them whole numbers or anything else than go ahead, dude.
            player.transform.position = new Vector3(-233.8236f, 7.981651f, 9.976563f);
            leftBound.transform.position = new Vector3(-250, leftBound.transform.position.y, leftBound.transform.position.z);
            rightBound.transform.position = new Vector3(-220, rightBound.transform.position.y, rightBound.transform.position.z);
        }

    }

    public void OnTriggerExit2D(Collider2D collision)
    {

        icon.SetActive(false);

    }

}
