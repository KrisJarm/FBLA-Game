﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Door : MonoBehaviour
{
    public BoxCollider2D hitbox;
    public GameObject doors;

    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        Collider2D[] results = new Collider2D[1];
        //ContactFilter2D contact = new ContactFilter2D();
        /*if(hitbox.OverlapCollider(new ContactFilter2D().NoFilter(), results) != 0)
        {
            Debug.Log("I touch");
            if (Input.GetKeyDown(KeyCode.Return) && results[0].gameObject.tag == "Player")
            {
                doors.SetActive(true);
                this.transform.parent.gameObject.SetActive(false);
                results[0].transform.position = new Vector2(-9f, -1.5f);
            }
        }*/
    }

    private void OnTriggerStay2D(Collider2D collision)
    {
        //Debug.Log("I touch");
        if (Input.GetKeyDown(KeyCode.Return) && collision.gameObject.tag == "Player")
        {
            doors.SetActive(true);
            this.transform.parent.gameObject.SetActive(false);
            collision.transform.position = new Vector2(-9f, -1.5f);
        }
    }
}
