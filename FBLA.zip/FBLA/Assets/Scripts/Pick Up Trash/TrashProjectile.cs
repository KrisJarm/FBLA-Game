﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TrashProjectile : MonoBehaviour
{
    public Rigidbody2D rb;
    public GameObject player;
    public int force;

    void Start()
    {
        //Debug.Log(Camera.main.ScreenToWorldPoint(Input.mousePosition));
        rb.AddForce((Camera.main.ScreenToWorldPoint(Input.mousePosition) - player.transform.position) * force);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
