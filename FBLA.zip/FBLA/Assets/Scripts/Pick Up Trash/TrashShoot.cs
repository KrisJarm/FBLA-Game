﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TrashShoot : MonoBehaviour
{
    public GameObject trash;
    public int numShots;
    
    // Start is called before the first frame update
    void Start()
    {
        numShots = 0;
    }

    // Update is called once per frame
    void Update()
    {
        if(numShots > 0 && Input.GetButtonDown("Fire1"))
        {
            Instantiate(trash, this.transform.position, Quaternion.identity).GetComponent<TrashProjectile>().player = this.gameObject;
            numShots--;
        }
    }

    public void Reload()
    {
        numShots++;
    }
}
