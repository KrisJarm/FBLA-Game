﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TrashProjectile : MonoBehaviour
{
    public Rigidbody2D rb;
    public int force;
    public bool collided;

    void Start()
    {
        //Debug.Log(Camera.main.ScreenToWorldPoint(Input.mousePosition));
        rb.AddForce((Camera.main.ScreenToWorldPoint(Input.mousePosition) - this.transform.position) * force);
        collided = false;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collided)
        {
            this.GetComponent<BoxCollider2D>().enabled = true;
            //this.GetComponent<TrashTrigger>().enabled = true;
            //Destroy(rb);
            Destroy(this);
        }
        else
        {
            collided = true;
        }
    }
}
