﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

public class Shoot : MonoBehaviour
{
    public float delay; // Delay between shots. 0 for no delay.
    private float delayCount;
    public GameObject projectile; // The thing you're shooting

    public bool needReload; // Whether or not you have limited ammo
    public int numShots; // Only if needReload = true; Counts ammo

    // Start is called before the first frame update
    void Start()
    {
        numShots = 0;
        delayCount = delay;
    }

    // Update is called once per frame
    void Update()
    {
        if(delayCount <= 0)
        {
            if ((!needReload || numShots > 0) && Input.GetButtonDown("Fire1"))
            {
                Physics2D.IgnoreCollision(Instantiate(projectile, this.transform.position, Quaternion.identity).GetComponent<Collider2D>(), this.GetComponent<Collider2D>());
                if (needReload) { numShots--; }
            }
        }
        else
        {
            delayCount -= Time.deltaTime;
        }
    }

    public void Reload()
    {
        numShots++;
    }
}
